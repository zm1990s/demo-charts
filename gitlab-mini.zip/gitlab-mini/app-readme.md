# 单节点 gitlab 应用

单节点 Gitlab，用于快速测试

